Rily Baly, a friends persona.

More info of this character can be found here https://toyhou.se/1565278.rily-baly

Keep up with my other projects https://ko-fi.com/cindercoon/

Special thanks to Zarla on deviantART and Zichqec (Zi) from Ukagaka Dream Team for tutorials, additions, and translations of certain parts of the code.

Hotspots:
   • Main Menu: Right-click anywhere on Rily
   • Playlist Menu: Right-click on his chest
   • Help Menu: Double left-click on his chest

   • Play/Next: Double-click his left eye
   • Play/Stop: Double-click his right eye
   • Song Bar: Double-click his right ear
   • Clear Playlist: Double-click on mouth

   • Pet Rily: Move the mouse over Rily's head


——— Version History ————

—v1.0.1—

• Code clean up
   Removing bloat
   Adding text for chatter 
• Update png files in master shell